"use client"
import { useState, useEffect, useRef } from "react"
import { useRouter, useParams } from "next/navigation"
import { ArrowLeft, Bold, Italic, List, Palette, Tag, Focus, EyeOff } from "lucide-react"
import toast from "react-hot-toast"

const MOODS = [
  { key: "happy",   emoji: "😊", label: "开心",   color: "#FFB74D" },
  { key: "calm",    emoji: "😌", label: "平静",   color: "#81C784" },
  { key: "excited", emoji: "🤩", label: "兴奋",   color: "#FF7043" },
  { key: "sad",     emoji: "😔", label: "低落",   color: "#64B5F6" },
  { key: "worried", emoji: "😰", label: "忧虑",   color: "#90A4AE" },
]

const COLORS = ["#333333", "#8BC34A", "#42A5F5", "#FF8C42", "#795548", "#e57373"]

export default function EditorPage() {
  const router = useRouter()
  const params = useParams()
  const id = params?.id as string | undefined
  const isNew = !id
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [mood, setMood] = useState<string | null>(null)
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [allTags, setAllTags] = useState<{ id: string; name: string }[]>([])
  const [saving, setSaving] = useState(false)
  const [focusMode, setFocusMode] = useState(false)
  const [showTagPicker, setShowTagPicker] = useState(false)
  const [newTagName, setNewTagName] = useState("")
  const [showColorPicker, setShowColorPicker] = useState(false)
  const editorRef = useRef<HTMLDivElement>(null)

  useEffect(() => { fetch("/api/tags").then(r => r.json()).then(d => { if (d.ok) setAllTags(d.data) }) }, [])

  useEffect(() => {
    if (id) {
      fetch(`/api/entries/${id}`).then(r => r.json()).then(d => {
        if (d.ok) { setTitle(d.data.title); setContent(d.data.content); setMood(d.data.mood); setSelectedTags(d.data.tags.map((t: { id: string }) => t.id)) }
      })
    }
  }, [id])

  function execCmd(cmd: string, value?: string) { document.execCommand(cmd, false, value); editorRef.current?.focus(); updateContent() }
  function updateContent() { if (editorRef.current) setContent(editorRef.current.innerHTML) }
  const charCount = content.replace(/<[^>]*>/g, "").replace(/\s/g, "").length

  async function handleSave(isDraft = false) {
    if (!title.trim() && !isDraft) { toast.error("标题不能为空"); return }
    setSaving(true)
    try {
      const body = { title: title.trim() || "无标题", content: editorRef.current?.innerHTML || "", mood, tagIds: selectedTags, isDraft }
      const res = await fetch(isNew ? "/api/entries" : `/api/entries/${id}`, { method: isNew ? "POST" : "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      const data = await res.json()
      if (data.ok) { toast.success(isDraft ? "草稿已保存" : "心得已保存"); router.push("/") } else toast.error(data.error || "保存失败")
    } catch { toast.error("网络异常") } finally { setSaving(false) }
  }

  function toggleTag(tagId: string) { setSelectedTags(prev => prev.includes(tagId) ? prev.filter(t => t !== tagId) : [...prev, tagId]) }

  async function createTag() {
    if (!newTagName.trim()) return
    try {
      const res = await fetch("/api/tags", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: newTagName.trim() }) })
      const data = await res.json()
      if (data.ok) { setAllTags(prev => [...prev, data.data]); setSelectedTags(prev => [...prev, data.data.id]); setNewTagName(""); toast.success("标签已创建") } else toast.error(data.error)
    } catch { toast.error("创建失败") }
  }

  return (
    <div className="min-h-screen pb-24" style={{ background: focusMode ? "#1a1a2e" : "#FAFAF5" }}>
      {!focusMode && (
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3" style={{ background: "rgba(250,250,245,0.95)", backdropFilter: "blur(12px)", borderBottom: "1px solid #e0e0e0" }}>
          <button onClick={() => router.back()} className="p-2"><ArrowLeft size={22} color="#666" /></button>
          <span className="text-sm font-medium" style={{ color: "#333" }}>{isNew ? "新心得" : "编辑心得"}</span>
          <div className="flex items-center gap-1">
            <button onClick={() => handleSave(true)} disabled={saving} className="px-3 py-1.5 text-xs rounded-full border transition" style={{ borderColor: "#ccc", color: "#666" }}>存草稿</button>
            <button onClick={() => handleSave(false)} disabled={saving} className="btn-sketch px-4 py-1.5 text-xs font-medium text-white" style={{ background: saving ? "#aaa" : "#8BC34A" }}>{saving ? "保存中…" : "保存"}</button>
          </div>
        </div>
      )}
      <div className="max-w-lg mx-auto">
        <input className="w-full text-xl font-bold outline-none px-4 pt-6 pb-2" style={{ color: focusMode ? "#eee" : "#333", background: "transparent" }} placeholder="给这颗种子取个名字…" value={title} onChange={e => setTitle(e.target.value)} />
        {!focusMode && (
          <div className="flex items-center gap-1 px-4 py-2 overflow-x-auto border-b" style={{ borderColor: "#e0e0e0" }}>
            <button onClick={() => execCmd("bold")} className="p-2 rounded-lg hover:bg-gray-100"><Bold size={18} color="#666" /></button>
            <button onClick={() => execCmd("italic")} className="p-2 rounded-lg hover:bg-gray-100"><Italic size={18} color="#666" /></button>
            <button onClick={() => execCmd("insertUnorderedList")} className="p-2 rounded-lg hover:bg-gray-100"><List size={18} color="#666" /></button>
            <div className="relative">
              <button onClick={() => setShowColorPicker(!showColorPicker)} className="p-2 rounded-lg hover:bg-gray-100"><Palette size={18} color="#666" /></button>
              {showColorPicker && (<div className="absolute top-10 left-0 bg-white border rounded-lg shadow-lg p-2 flex gap-1 z-10">{COLORS.map(c => (<button key={c} onClick={() => { execCmd("foreColor", c); setShowColorPicker(false) }} className="w-7 h-7 rounded-full border-2 hover:scale-110 transition-transform" style={{ background: c, borderColor: c }} />))}</div>)}
            </div>
            <div className="w-px h-5 mx-1" style={{ background: "#e0e0e0" }} />
            <button onClick={() => setShowTagPicker(!showTagPicker)} className="p-2 rounded-lg hover:bg-gray-100"><Tag size={18} color={selectedTags.length ? "#8BC34A" : "#666"} /></button>
            <button onClick={() => setFocusMode(true)} className="p-2 rounded-lg hover:bg-gray-100"><Focus size={18} color="#666" /></button>
            <span className="ml-auto text-xs" style={{ color: "#bbb" }}>{charCount} 字</span>
          </div>
        )}
        {focusMode && <button onClick={() => setFocusMode(false)} className="fixed top-4 right-4 z-20 p-2 rounded-full opacity-50 hover:opacity-100" style={{ background: "rgba(255,255,255,0.1)" }}><EyeOff size={20} color="#aaa" /></button>}
        <div ref={editorRef} contentEditable className="w-full outline-none text-sm leading-relaxed" style={{ padding: focusMode ? "40px 24px" : "16px", minHeight: focusMode ? "60vh" : "30vh", color: focusMode ? "#ddd" : "#333" }} onInput={updateContent} dangerouslySetInnerHTML={{ __html: content }} data-placeholder="在这里写下你的感悟、想法或日记…" />
        {!focusMode && (
          <div className="px-4 py-3 border-t" style={{ borderColor: "#e0e0e0" }}>
            <p className="text-xs mb-2" style={{ color: "#999" }}>此刻的心情</p>
            <div className="flex gap-3">{MOODS.map(m => (
              <button key={m.key} onClick={() => setMood(mood === m.key ? null : m.key)} className="flex flex-col items-center gap-0.5 px-3 py-2 rounded-xl transition" style={{ background: mood === m.key ? `${m.color}20` : "transparent", border: mood === m.key ? `2px solid ${m.color}` : "2px solid transparent" }}>
                <span className="text-xl">{m.emoji}</span><span className="text-[10px]" style={{ color: mood === m.key ? m.color : "#999" }}>{m.label}</span>
              </button>
            ))}</div>
          </div>
        )}
        {showTagPicker && !focusMode && (
          <div className="px-4 py-3 border-t animate-fade-in" style={{ borderColor: "#e0e0e0" }}>
            <div className="flex items-center gap-2 mb-2">
              <input className="input-sketch flex-1 px-3 py-2 text-sm outline-none" style={{ border: "1.5px solid #ccc", background: "#fafaf5" }} placeholder="新建标签名" value={newTagName} onChange={e => setNewTagName(e.target.value)} onKeyDown={e => e.key === "Enter" && createTag()} />
              <button onClick={createTag} className="px-3 py-2 text-sm rounded-full text-white" style={{ background: "#8BC34A" }}>添加</button>
            </div>
            <div className="flex flex-wrap gap-2">{allTags.map(tag => (
              <button key={tag.id} onClick={() => toggleTag(tag.id)} className="px-3 py-1.5 rounded-full text-xs font-medium transition" style={{ background: selectedTags.includes(tag.id) ? "#8BC34A" : "#f0f0f0", color: selectedTags.includes(tag.id) ? "#fff" : "#666" }}>{tag.name}</button>
            ))}</div>
          </div>
        )}
      </div>
      {focusMode && (<div className="fixed bottom-0 left-0 right-0 flex justify-center gap-3 p-4 pb-8" style={{ background: "linear-gradient(transparent, rgba(26,26,46,0.95))" }}><button onClick={() => handleSave(true)} className="px-6 py-2 rounded-full text-sm text-white border" style={{ borderColor: "rgba(255,255,255,0.3)" }}>存草稿</button><button onClick={() => handleSave(false)} className="px-6 py-2 rounded-full text-sm font-medium text-white" style={{ background: "#8BC34A" }}>保存</button></div>)}
      <style>{`[contenteditable]:empty:before{content:attr(data-placeholder);color:#bbb;pointer-events:none}`}</style>
    </div>
  )
}
