﻿import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { verifyPassword, signToken, COOKIE_CONFIG } from "@/lib/auth"
import { cookies } from "next/headers"

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json()
    if (!email || !password)
      return NextResponse.json({ ok: false, error: "邮箱和密码不能为空" }, { status: 400 })

    const user = await prisma.user.findUnique({ where: { email } })
    if (!user)
      return NextResponse.json({ ok: false, error: "邮箱或密码错误" }, { status: 401 })

    if (!user.isVerified)
      return NextResponse.json({ ok: false, error: "邮箱未验证，请先完成验证", data: { userId: user.id, needVerify: true } }, { status: 401 })

    const ok = await verifyPassword(password, user.passwordHash)
    if (!ok)
      return NextResponse.json({ ok: false, error: "邮箱或密码错误" }, { status: 401 })

    const token = signToken(user.id)
    const cookieStore = await cookies()
    cookieStore.set(COOKIE_CONFIG.name, token, COOKIE_CONFIG.options)

    // 更新打开次数
    await prisma.user.update({ where: { id: user.id }, data: { openTimes: { increment: 1 } } })

    return NextResponse.json({ ok: true, data: { onboardDone: user.onboardDone } })
  } catch (e) {
    console.error("[login]", e)
    return NextResponse.json({ ok: false, error: "登录失败，请稍后再试" }, { status: 500 })
  }
}
