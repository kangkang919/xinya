﻿"use client"
import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Sprout, Leaf, Sun, TreePine, Plus } from "lucide-react"

const TABS = [
  { key: "sprout", label: "萌芽", path: "/",       Icon: Sprout   },
  { key: "leaf",   label: "枝叶", path: "/leaf",   Icon: Leaf     },
  { key: "ring",   label: "年轮", path: "/ring",   Icon: Sun      },
  { key: "root",   label: "根系", path: "/root",   Icon: TreePine },
]

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const pathname = usePathname()
  const [checked, setChecked] = useState(false)
  const [theme, setTheme] = useState("spring")

  // 登录守卫
  useEffect(() => {
    fetch("/api/auth/me")
      .then(r => r.json())
      .then(data => {
        if (!data.ok) { router.replace("/login"); return }
        if (!data.data.onboardDone) { router.replace("/onboard"); return }
        setTheme(data.data.theme || "spring")
        setChecked(true)
      })
      .catch(() => router.replace("/login"))
  }, [router])

  if (!checked) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#FAFAF5" }}>
      <div className="text-4xl animate-bounce-gentle">🌱</div>
    </div>
  )

  const active = TABS.find(t => t.path === pathname)?.key || "sprout"

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "#FAFAF5" }}
      data-theme={theme}>
      {/* 主内容区 */}
      <main className="flex-1 overflow-y-auto pb-24">
        {children}
      </main>

      {/* 底部导航 */}
      <nav className="fixed bottom-0 left-0 right-0 pb-safe"
        style={{ background: "rgba(255,255,255,0.95)", borderTop: "1px solid #e0e0e0", backdropFilter: "blur(12px)" }}>
        <div className="flex items-end justify-around px-2 pt-2 pb-1 max-w-lg mx-auto">
          {/* 左边两个Tab */}
          {TABS.slice(0,2).map(({ key, label, path, Icon }) => (
            <button key={key} onClick={() => router.push(path)}
              className="flex flex-col items-center gap-0.5 px-4 py-1 rounded-xl transition-all"
              style={{ color: active === key ? "#8BC34A" : "#aaa" }}>
              <Icon size={22} strokeWidth={active === key ? 2.5 : 1.8} />
              <span className="text-[10px] font-medium">{label}</span>
            </button>
          ))}

          {/* 中央新建按钮 */}
          <button onClick={() => router.push("/entry/new")}
            className="flex items-center justify-center rounded-full shadow-lg mb-3 transition-transform active:scale-95"
            style={{ width: 52, height: 52, background: "linear-gradient(135deg, #8BC34A, #AED581)" }}>
            <Plus size={26} color="white" strokeWidth={2.5} />
          </button>

          {/* 右边两个Tab */}
          {TABS.slice(2).map(({ key, label, path, Icon }) => (
            <button key={key} onClick={() => router.push(path)}
              className="flex flex-col items-center gap-0.5 px-4 py-1 rounded-xl transition-all"
              style={{ color: active === key ? "#8BC34A" : "#aaa" }}>
              <Icon size={22} strokeWidth={active === key ? 2.5 : 1.8} />
              <span className="text-[10px] font-medium">{label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  )
}
