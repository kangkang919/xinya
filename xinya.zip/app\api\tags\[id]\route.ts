import { NextRequest, NextResponse } from "next/server"
import { getCurrentUserId } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

// DELETE /api/tags/[id]
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const userId = await getCurrentUserId()
  if (!userId) return NextResponse.json({ ok: false }, { status: 401 })
  const { id } = await params

  const tag = await prisma.tag.findFirst({ where: { id, userId } })
  if (!tag) return NextResponse.json({ ok: false, error: "未找到标签" }, { status: 404 })
  if (tag.isDefault) return NextResponse.json({ ok: false, error: "默认标签不可删除" }, { status: 400 })

  await prisma.tag.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}